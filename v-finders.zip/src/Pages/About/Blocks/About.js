import react from 'react';
import {FacebookBtn,SignUp, GoogleBtn} from '../../../Layout/Blocks/Widgets';
import Layout from '../../../Layout/Layout';





const About = () =>(
    <div className='uk-container'>
       <Layout>
     

      </Layout>

</div>


    
)


export default About